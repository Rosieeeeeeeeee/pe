using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PEGARIDO_PhotoAlbum.Pages.Pages
{
    public class Photos4Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
