using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PEGARIDO_PhotoAlbum.Pages.Pages
{
    public class Photos5Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
